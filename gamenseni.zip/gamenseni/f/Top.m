//
//  Top.m
//  f
//
//  Created by e125740 on 2013/11/20.
//  Copyright (c) 2013年 Yukiya IHA. All rights reserved.
//

#import "Top.h"

@interface Top ()

@end

@implementation Top

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
        
    UIBarButtonItem *back = [[UIBarButtonItem alloc] init];
    back.image = [UIImage imageNamed:@"kuma2.png"]; // 画像の設定
	self.navigationItem.backBarButtonItem = back;

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
