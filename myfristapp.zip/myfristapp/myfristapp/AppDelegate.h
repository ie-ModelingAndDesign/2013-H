//
//  AppDelegate.h
//  myfristapp
//
//  Created by Chie AHAREN on 2013/11/24.
//  Copyright (c) 2013年 Chie AHAREN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
