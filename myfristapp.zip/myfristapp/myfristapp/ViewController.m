//
//  ViewController.m
//  myfristapp
//
//  Created by Chie AHAREN on 2013/11/24.
//  Copyright (c) 2013年 Chie AHAREN. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)button:(id)sender {
    //self.label.text=@"you push!";
    // intValue =5;
    //NSLog(@"int:%d", intValue);
    
    switch(c){
    case'0': count=1;
	self.label.text = [NSString stringWithFormat:@"%d", count];
        c++;
            break;
    case'1':self.label.text = [NSString stringWithFormat:@"%d", count];
        c++;
            break;
    default:self.label.text = [NSString stringWithFormat:@"%d", count];
            break;
    }
}

- (IBAction)button2:(id)sender {
    count=2;
	self.label.text = [NSString stringWithFormat:@"%d", count];
}
@end
