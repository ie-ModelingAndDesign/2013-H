//
//  ViewController.h
//  myfristapp
//
//  Created by Chie AHAREN on 2013/11/24.
//  Copyright (c) 2013年 Chie AHAREN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
	int  count;
    int c;
}
- (IBAction)button:(id)sender;
- (IBAction)button2:(id)sender;


@property (weak, nonatomic) IBOutlet UILabel *label;
@end
